package ProSit1.src;

public class Magasin {
    private String identifiant;
    private String adresse;
    private int capacite;
    private Produit[] produits;  // Fixed-size array of products
    private int nombreProduits;   // Counter to track the number of products added

    // Constructor
    public Magasin(String identifiant, String adresse, int capacite) {
        this.identifiant = identifiant;
        this.adresse = adresse;
        this.capacite = capacite;
        this.produits = new Produit[capacite];  // Initialize array with the capacity
        this.nombreProduits = 0;  // Initialize product count
    }

    // Method to add a product to the store
    public void ajouterProduit(Produit produit) {
        if (nombreProduits < capacite) {
            produits[nombreProduits] = produit;
            nombreProduits++;
            System.out.println("Produit ajouté : " + produit.nom);
        } else {
            System.out.println("Capacité maximale atteinte. Impossible d'ajouter plus de produits.");
        }
    }

    public void afficherMagasin() {
        System.out.println("Identifiant : " + identifiant);
        System.out.println("Adresse : " + adresse);
        System.out.println("Capacité : " + capacite);
        System.out.println("Produits dans le magasin : ");

        for (int i = 0; i < nombreProduits; i++) {
            produits[i].Afficher();
            System.out.println();
        }
    }

    public int getNombreTotalProduits() {
        return nombreProduits;
    }
}
