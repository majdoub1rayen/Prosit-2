package ProSit1.src;

public class Main {
    public static void main(String[] args) {

        Magasin Magasin = new Magasin("001", "Avenue de France", 50);

        Produit produit1 = new Produit(101, "Laptop", "Dell", 1500);
        Produit produit2 = new Produit(102, "Smartphone", "Samsung", 800);
        Produit produit3 = new Produit(103, "Tablet", "Apple", 1200);

        Magasin.ajouterProduit(produit1);
        Magasin.ajouterProduit(produit2);
        Magasin.ajouterProduit(produit3);

        Magasin.afficherMagasin();

        System.out.println("Nombre total de produits: " + Magasin.getNombreTotalProduits());
    }
}