import java.util.Scanner;

public class Calcul {

    public static int saisiPositive () {
        int a;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Veuillez entrer un numero positive");
            a = sc.nextInt();
        } while (a < 0);

        return a;


    }
    public static int saisidifferntZero () {
        int a;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Veuillez entrer un numero <> 0");
            a = sc.nextInt();
        } while (a == 0);

        return a;


    }

    public static  int somme (int a, int b){
        return a+b;
    }
    public static int somme2(String x1, String x2){

        int n1 = Integer.parseInt(x1);
        int n2 = Integer.parseInt(x2);
        return n1+n2;
    }

    public static void Afficher (float x){
        System.out.println(x);
    }


    public static void main(String[] args) {
        int n1=5;
        int n2=6;

        int somme = somme(n1,n2);
//        Scanner s1 = new Scanner(System.in);
//        System.out.println("Veuillez entrer un numero");
//        int x =s1.nextInt();
//        System.out.println("Veuillez entrer un autre numero");
//        int y =s1.nextInt();
      //  int x = saisiPositive();
        int x1 = saisidifferntZero();

       // Afficher(somme);

       // System.out.println("le resultat :"+args[0]+" + "+args[1]+" = " +somme2(args[0],args[1]));
       // System.out.println(x+" + "+y +" = " +somme(x,y));
        System.out.println(x1+"  vrai");
    }


}
